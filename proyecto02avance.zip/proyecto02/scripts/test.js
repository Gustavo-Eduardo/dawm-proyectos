function main() {
    const getPokemonsButton = document.getElementById("all-pokemons")
    getPokemonsButton.onclick = requestPokemons
}

let requestFulfilled = false

function requestPokemons() {
    if (!requestFulfilled) {
        const url = "./testData/pokemonPages/page1/pageData.json"
        fetch(url).then(response => response.json()).then(data => {
            data.results.forEach(pokemon => {
                const url = `./testData/pokemonPages/page1/${pokemon.name}.json`
                requestPokemon(url)

            })

        })
    }
    requestFulfilled = true
}

function requestPokemon(url) {
    fetch(url).then(response => response.json()).then(pokemon => {
        const pokemonElement = document.createElement("div")
        pokemonElement.setAttribute("id", pokemon.forms[0].name)

        const h1 = document.createElement("h1")
        h1.innerHTML = pokemon.forms[0].name

        pokemonElement.appendChild(h1)

        pokemon.types.forEach((typeSlot, i) => {
            const h2 = document.createElement("h2")
            h2.innerHTML += `Type ${i + 1}: ${typeSlot.type.name}`
            pokemonElement.appendChild(h2)
        })


        const section = document.getElementById("pokemons")
        section.appendChild(pokemonElement)

    })
}

main()